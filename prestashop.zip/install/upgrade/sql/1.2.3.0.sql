SET NAMES 'utf8';

ALTER TABLE `PREFIX_category_product` ADD INDEX (`id_product`);
