SET NAMES 'utf8';

/* ##################################### */
/* 				STRUCTURE			 		 */
/* ##################################### */


/* ##################################### */
/* 					CONTENTS					 */
/* ##################################### */

INSERT INTO PREFIX_configuration (name, value, date_add, date_upd) VALUES ('PS_THEME_V11', 0, NOW(), NOW());

/* PHP */
/* PHP:update_carrier_url(); */;
/* PHP:module_reinstall_blocksearch(); */;
